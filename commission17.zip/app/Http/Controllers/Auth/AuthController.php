<?php

namespace App\Http\Controllers\Auth;

use App\User;
use Validator;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;

class AuthController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Registration & Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users, as well as the
    | authentication of existing users. By default, this controller uses
    | a simple trait to add these behaviors. Why don't you explore it?
    |
    */

    use AuthenticatesAndRegistersUsers, ThrottlesLogins;

    /**
     * Where to redirect users after login / registration.
     *
     * @var string
     */
    protected $redirectTo = '/';

    /**
     * Create a new authentication controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware($this->guestMiddleware(), ['except' => 'logout']);
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'surname' => 'required|max:255',
            'Fname' => 'required|max:255',
            'othernames' => 'required|max:255',
            'contactaddress' => 'max:255',
            'postcode' => 'max:255',
            'email' => 'required|email|max:255|unique:users',
            'tel' => 'required|max:30',
            'nationality' => 'required|max:255',
            'idno' => 'required|max:30',
            'marital_status' => 'required|max:20',
            'speciality' => 'required|max:255',
            'graduation_year' => 'required|min:4',
            'year_of_study' => 'required|max:1',
            'campus' => 'required|max:255',
            'church' => 'required|max:255',
            'special_requirements' => 'max:255',
            'password' => 'required|min:6|confirmed',
            'accommodation' => 'required',

            'emergency_name' => 'max:255',
            'emergency_relationship' => 'max:255',
            'emergency_phone_no' => 'max:30',
            'emergency_email' => 'email|max:255',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {
        $marital_status = $data['marital_status'] == 'other' ? $data['marital_status_other'] : $data['marital_status'];

        $physical_limitations = $data['visually_impaired'] == null ? "" : $data['visually_impaired'].", ";
        $physical_limitations = $data['wheelchair'] == null ? "" : $data['wheelchair'].", ";
        $physical_limitations .= $data['crutches'] == null ? "" : $data['crutches'].", ";
        $physical_limitations .= $data['other_limitations'] == null ? "" : $data['other_limitations'];

        return User::create([
            'surname' => $data['surname'],
            'Fname' => $data['Fname'],
            'othernames' => $data['othernames'],
            'contactaddress' => $data['contactaddress'],
            'postcode' => $data['postcode'],
            'email' => $data['email'],
            'tel' => $data['tel'],
            'nationality' => $data['nationality'],
            'idno' => $data['idno'],
            'marital_status' => $marital_status,
            'speciality' => $data['speciality'],
            'graduation_year' => $data['graduation_year'],
            'year_of_study' => $data['year_of_study'],
            'campus' => $data['campus'],
            'church' => $data['church'],
            'special_requirements' => $data['special_requirements'],
            'password' => bcrypt($data['password']),
            'physical_limitations' => $physical_limitations,
            'accommodation' => $data['accommodation'],

            'emergency_name' => $data['emergency_name'],
            'emergency_relationship' => $data['emergency_relationship'],
            'emergency_phone_no' => $data['emergency_phone_no'],
            'emergency_email' => $data['emergency_email'],
        ]);
    }
}
