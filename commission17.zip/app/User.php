<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'surname', 'Fname', 'othernames', 'contactaddress', 'postcode', 'email', 'tel', 'nationality', 'idno', 'marital_status', 'speciality', 'graduation_year', 'year_of_study', 'campus', 'church', 'special_requirements', 'password', 'physical_limitations', 'accommodation', 'emergency_name', 'emergency_relationship', 'emergency_phone_no', 'emergency_email',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
}
