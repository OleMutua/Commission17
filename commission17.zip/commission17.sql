-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 25, 2017 at 10:06 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `commission17`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `surname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Fname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `othernames` char(255) COLLATE utf8_unicode_ci NOT NULL,
  `contactaddress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `postcode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tel` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `nationality` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `idno` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `marital_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `speciality` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `graduation_year` int(4) NOT NULL,
  `year_of_study` int(1) NOT NULL,
  `campus` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `church` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `special_requirements` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `physical_limitations` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `accommodation` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `emergency_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `emergency_relationship` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `emergency_phone_no` int(30) NOT NULL,
  `emergency_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `surname`, `Fname`, `othernames`, `contactaddress`, `postcode`, `email`, `tel`, `nationality`, `idno`, `marital_status`, `speciality`, `graduation_year`, `year_of_study`, `campus`, `church`, `special_requirements`, `password`, `remember_token`, `physical_limitations`, `accommodation`, `emergency_name`, `emergency_relationship`, `emergency_phone_no`, `emergency_email`, `created_at`, `updated_at`) VALUES
(1, 'Mutua', 'Ancent', 'Musee', '', '', 'a.musee94@gmail.com', '', '', '', '', '', 0, 0, '', '', '', '$2y$10$/f0IltMfjm87ki5.M.5W/O0/3ouU7q2sJhQe4VTu4t.nOLawb0zza', '15pm2Vkt4k2wIAVV52wJ9FU1BjOw0cIc9eW0PL47C06jyQhPTqacNFQAun9W', '', '', '', '', 0, '', '2017-03-14 17:06:44', '2017-03-15 10:32:02'),
(3, 'martin', 'marube', 'mogusu', '789', '456789', 'martin@mogusu.com', '78935678', 'Kenyan', '87654456', '', 'Comp', 2019, 3, 'JKUAT', 'church', '', '$2y$10$AXh3zVz3jEoKLeUMMWuoVuGDjyWLk7w9GfamiKSLraRGEoPOW73wu', 'j45a16g2qesopGPrcwoTM2fT8L4wRpbl4IanjDC8L14eJAN5YmlyfzmWysTa', '', 'student', 'Musee', 'friend', 725522533, 'a.musee94@gmail.com', '2017-03-20 11:06:35', '2017-03-20 11:07:55'),
(4, 'John', 'Doe', 'Doew', '12344', '9853', 'john@doe.com', '94537738464', 'Kenyan', '89756890', 'Divorced', 'Maths', 2020, 2, 'JKUAT', 'kanisa', '', '$2y$10$tA9YZgEB01BmknKph1WM1.ViC5YxJWzeh70.3wuNcmK/GVZGtw9uu', 'Y72zrZzPZ5CZJOPEovvmbrcIzRj78qI4PVhhsvxicbhg5mJnbau0Jc1aX9bx', '', 'student', 'Musee', 'someone I know', 725522533, 'a.musee94@gmail.com', '2017-03-20 11:28:53', '2017-03-20 11:36:29'),
(5, 'martin', 'marube', 'mogusu', '12344', '9876', 'john1@doe.com', '0737924614', 'Kenyan', '89756890', '', 'GEGIS', 2021, 2, 'KMTC', 'church', '', '$2y$10$Yqch2ioVtkAFad7C7mLMregwPsseCryXzSY2iihN4bLeLyqox0tem', 'zv3oHTUZoU5eCwjJ8j3ylEJtOF5n2NcrudjBY5rlBr7PDErvNwyWzc3LYuFr', 'other', 'student', 'Musee', 'someone I know', 725522533, 'a.musee94@gmail.com', '2017-03-20 11:42:25', '2017-03-20 11:43:55'),
(6, 'Marube', 'Martin', 'mogusu', '98976', '098868', 'user@mail.com', '8976569', '87684367', '87906987', 'married', 'GEGIS', 2020, 3, 'JKUAT', 'kanisa', '', '$2y$10$sg0GcfvjhswDRukC6ndNJOzgrFxpQueB9pee48dqCMCNN6D64AmSW', 'MRD2Ka5SPXbxYbaOy1SLCmS4uilIv5i9Oyn9OMkv5hWcbyNxepCfS6oiRiga', 'wheelchair, crutches, Hearing disability', 'student', 'Musee', 'someone I know', 725522533, 'a.musee94@gmail.com', '2017-03-20 11:57:47', '2017-03-20 12:03:17');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
