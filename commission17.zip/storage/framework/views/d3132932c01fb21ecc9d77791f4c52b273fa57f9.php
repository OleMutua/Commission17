<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"> <strong> COMMISSION 2017 CONFERENCE REGISTRATION FORM </strong> </div>
                <div class="panel-body">

                    <p> Fill in or tick as appropriate. The fields marked * must be filled </p>
                    
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/register')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <!-- Surname Field -->

                        <div class="form-group<?php echo e($errors->has('surname') ? ' has-error' : ''); ?>">
                            <label for="surname" class="col-md-4 control-label">*Surname</label>

                            <div class="col-md-6">
                                <input id="surname" type="text" class="form-control" name="surname" value="<?php echo e(old('surname')); ?>" required="">

                                <?php if($errors->has('surname')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('surname')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- First Name field -->

                        <div class="form-group<?php echo e($errors->has('Fname') ? ' has-error' : ''); ?>">
                            <label for="Fname" class="col-md-4 control-label">*First Name</label>

                            <div class="col-md-6">
                                <input id="Fname" type="text" class="form-control" name="Fname" value="<?php echo e(old('Fname')); ?>" required="">

                                <?php if($errors->has('Fname')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('Fname')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Other Names field -->

                        <div class="form-group<?php echo e($errors->has('othernames') ? ' has-error' : ''); ?>">
                            <label for="othernames" class="col-md-4 control-label"> *Other Names</label>

                            <div class="col-md-6">
                                <input id="othernames" type="text" class="form-control" name="othernames" value="<?php echo e(old('othernames')); ?>" required="">

                                <?php if($errors->has('othernames')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('othernames')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Contact Address field -->

                        <div class="form-group<?php echo e($errors->has('contactaddress') ? ' has-error' : ''); ?>">
                            <label for="contactaddress" class="col-md-4 control-label"> Contact Address </label>

                            <div class="col-md-6">
                                <input id="contactaddress" type="text" class="form-control" name="contactaddress" value="<?php echo e(old('contactaddress')); ?>">

                                <?php if($errors->has('contactaddress')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('contactaddress')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Post Code field -->

                        <div class="form-group<?php echo e($errors->has('postcode') ? ' has-error' : ''); ?>">
                            <label for="postcode" class="col-md-4 control-label"> Post Code </label>

                            <div class="col-md-6">
                                <input id="postcode" type="text" class="form-control" name="postcode" value="<?php echo e(old('postcode')); ?>">

                                <?php if($errors->has('postcode')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('postcode')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Email Address Field -->

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label">*E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Telephone Number Field -->

                        <div class="form-group<?php echo e($errors->has('tel') ? ' has-error' : ''); ?>">
                            <label for="tel" class="col-md-4 control-label"> *Tel Number </label>

                            <div class="col-md-6">
                                <input id="tel" type="text" class="form-control" name="tel" value="<?php echo e(old('tel')); ?>" required="">

                                <?php if($errors->has('tel')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('tel')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Nationality Field -->

                        <div class="form-group<?php echo e($errors->has('nationality') ? ' has-error' : ''); ?>">
                            <label for="nationality" class="col-md-4 control-label"> *Nationality </label>

                            <div class="col-md-6">
                                <input id="nationality" type="text" class="form-control" name="nationality" value="<?php echo e(old('nationality')); ?>" required="">

                                <?php if($errors->has('nationality')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('nationality')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- ID/PASSPORT NO Field -->

                        <div class="form-group<?php echo e($errors->has('idno') ? ' has-error' : ''); ?>">
                            <label for="idno" class="col-md-4 control-label"> *ID/PASSPORT Number </label>

                            <div class="col-md-6">
                                <input id="idno" type="text" class="form-control" name="idno" value="<?php echo e(old('idno')); ?>" required="">

                                <?php if($errors->has('idno')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('idno')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Accommodation Field -->

                        <div class="form-group<?php echo e($errors->has('marital_status') ? ' has-error' : ''); ?>">

                            <div class="form-group">
                            

                                <?php if($errors->has('marital_status')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('marital_status')); ?></strong>
                                    </span>
                                <?php endif; ?>

                              <label class="col-md-4 control-label" for="marital_status" required"">*Marital Status</label>
                              <div class="col-md-4">
                              <div class="checkbox">
                                <label for="single">
                                  <input name="marital_status" id="single" value="single" type="checkbox">
                                  Single
                                </label>
                                </div>
                              <div class="checkbox">
                                <label for="married">
                                  <input name="marital_status" id="married" value="married" type="checkbox">
                                  Married
                                </label>
                                </div>
                                 <div class="checkbox">
                                <label for="other">
                                  <input name="marital_status" id="other" value="other" type="checkbox">
                                  Other

                                  <input name="marital_status_other" id="other1" value="" type="text" placeholder="Specify"> </input>
                                </label>
                                </div>
                              </div>
                            </div>
                        </div>

                        <!-- Category Field -->

                        <!-- <div class="form-group<?php echo e($errors->has('category') ? ' has-error' : ''); ?>">

                            <div class="form-group">
                            

                                <?php if($errors->has('category')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('category')); ?></strong>
                                    </span>
                                <?php endif; ?>

                              <label class="col-md-4 control-label" for="category" required"">*Category</label>
                              <div class="col-md-4">
                              <div class="radio">
                                <label for="student">
                                  <input name="student" id="student" value="<?php echo e(old('student')); ?>" type="radio">
                                  Student
                                </label>
                                </div>
                              <div class="radio">
                                <label for="associate">
                                  <input name="associate" id="associate" value="<?php echo e(old('associate')); ?>" type="radio">
                                  Associate
                                </label>
                                </div>
                              <div class="radio">
                                <label for="speaker">
                                  <input name="speaker" id="speaker" value="<?php echo e(old('speaker')); ?>" type="radio">
                                  Speaker
                                </label>
                                </div>
                              </div>
                            </div>
                        </div>
 -->
                        
                        <!-- Speciality Field -->

                        <div class="form-group<?php echo e($errors->has('speciality') ? ' has-error' : ''); ?>">
                            <label for="speciality" class="col-md-4 control-label"> *Area of speciality in studies </label>

                            <div class="col-md-6">
                                <input id="speciality" type="text" class="form-control" name="speciality" value="<?php echo e(old('speciality')); ?>" required="">

                                <?php if($errors->has('speciality')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('speciality')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Year of Graduation Field -->

                        <div class="form-group<?php echo e($errors->has('graduation_year') ? ' has-error' : ''); ?>">
                            <label for="graduation_year" class="col-md-4 control-label"> *Anticipated year of graduation</label>

                            <div class="col-md-6">
                                <input id="graduation_year" type="text" class="form-control" name="graduation_year" value="<?php echo e(old('graduation_year')); ?>" required="">
                                <!-- <select>
                                  <option value="2017">2017</option>
                                  <option value="2018">2018</option>
                                  <option value="2019">2019</option>
                                  <option value="2020">2020</option>
                                  <option value="2021">2021</option>
                                  <option value="2022">2022</option>
                                  <option value="2023">2023</option>
                                  <option value="2024">2024</option>
                                  <option value="2025">2025</option>
                                </select> -->


                                <?php if($errors->has('graduation_year')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('graduation_year')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Year of study Field -->

                        <div class="form-group<?php echo e($errors->has('year_of_study') ? ' has-error' : ''); ?>">
                            <label for="year_of_study" class="col-md-4 control-label"> *Year of Study</label>

                            <div class="col-md-6">
                                <input id="year_of_study" type="text" class="form-control" name="year_of_study" value="<?php echo e(old('year_of_study')); ?>" required="">

                                <?php if($errors->has('year_of_study')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('year_of_study')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Campus/College Field -->

                        <div class="form-group<?php echo e($errors->has('campus') ? ' has-error' : ''); ?>">
                            <label for="campus" class="col-md-4 control-label"> *Campus/College</label>

                            <div class="col-md-6">
                                <input id="campus" type="text" class="form-control" name="campus" value="<?php echo e(old('campus')); ?>" required="">

                                <?php if($errors->has('campus')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('campus')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Church Field -->

                        <div class="form-group<?php echo e($errors->has('church') ? ' has-error' : ''); ?>">
                            <label for="church" class="col-md-4 control-label"> *Home Church/Denomination</label>

                            <div class="col-md-6">
                                <input id="church" type="text" class="form-control" name="church" value="<?php echo e(old('church')); ?>" required="">

                                <?php if($errors->has('church')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('church')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Special Requirements Field -->

                        <div class="form-group<?php echo e($errors->has('special_requirements') ? ' has-error' : ''); ?>">
                            <label for="special_requirements" class="col-md-4 control-label">Any special requirements? (e.g. Allergy, Diet etc)</label>

                            <div class="col-md-6">
                                <input id="special_requirements" type="text" class="form-control" name="special_requirements" value="<?php echo e(old('special_requirements')); ?>">

                                <?php if($errors->has('special_requirements')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('special_requirements')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <!-- Physical limitations Field -->

                        <div class="form-group<?php echo e($errors->has('physical_limitations') ? ' has-error' : ''); ?>">

                            <div class="form-group">
                            

                                <?php if($errors->has('physical_limitations')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('physical_limitations')); ?></strong>
                                    </span>
                                <?php endif; ?>

                              <label class="col-md-4 control-label" for="physical_limitations" required"">*Physical Limitations</label>
                              <div class="col-md-4">
                              <div class="checkbox">
                                <label for="visually_impaired">
                                  <input name="visually_impaired" id="visually_impaired" value="visually_impaired" type="checkbox">
                                  Visually impaired
                                </label>
                                </div>
                              <div class="checkbox">
                                <label for="wheelchair">
                                  <input name="wheelchair" id="wheelchair" value="wheelchair" type="checkbox">
                                  Wheelchair
                                </label>
                                </div>
                                <div class="checkbox">
                                <label for="crutches">
                                  <input name="crutches" id="crutches" value="crutches" type="checkbox">
                                  Crutches
                                </label>
                                </div>
                                 <div class="checkbox">
                                <label for="other">
                                  <input name="other" id="other" value="other" type="checkbox">
                                  Other

                                  <input name="other_limitations" id="other1" type="text" placeholder="Specify"> </input>
                                </label>
                                </div>
                              </div>
                            </div>
                        </div>

                                                <!-- Accommodation Field -->

                        <div class="form-group<?php echo e($errors->has('accommodation') ? ' has-error' : ''); ?>">

                            <div class="form-group">
                            

                                <?php if($errors->has('accommodation')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('accommodation')); ?></strong>
                                    </span>
                                <?php endif; ?>

                              <label class="col-md-4 control-label" for="accommodation" required"">*Accomodation</label>
                              <div class="col-md-4">
                              <div class="radio">
                                <label for="border">
                                  <input name="accommodation" id="border" value="student" type="radio">
                                  Boarder
                                </label>
                                </div>
                              <div class="radio">
                                <label for="dayscholar">
                                  <input name="accommodation" id="dayscholar" value="dayscholar" type="radio">
                                  Day scholar
                                </label>
                                </div>
                              </div>
                            </div>
                        </div>


                        <p><h1>*Emergency Contacts:</h1></p>

                        <!-- Emergency Contact Name -->

                        <div class="form-group<?php echo e($errors->has('emergency_name') ? ' has-error' : ''); ?>">
                            <label for="emergency_name" class="col-md-4 control-label">Name</label>

                            <div class="col-md-6">
                                <input id="emergency_name" type="text" class="form-control" name="emergency_name" value="<?php echo e(old('emergency_name')); ?>">

                                <?php if($errors->has('emergency_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('emergency_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Emergency Contact Relationship -->

                        <div class="form-group<?php echo e($errors->has('emergency_relationship') ? ' has-error' : ''); ?>">
                            <label for="emergency_relationship" class="col-md-4 control-label">Relationship</label>

                            <div class="col-md-6">
                                <input id="emergency_relationship" type="text" class="form-control" name="emergency_relationship" value="<?php echo e(old('emergency_relationship')); ?>">

                                <?php if($errors->has('emergency_relationship')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('emergency_relationship')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Emergency Contact Phone -->

                        <div class="form-group<?php echo e($errors->has('emergency_phone_no') ? ' has-error' : ''); ?>">
                            <label for="emergency_phone_no" class="col-md-4 control-label">Phone Number</label>

                            <div class="col-md-6">
                                <input id="emergency_phone_no" type="text" class="form-control" name="emergency_phone_no" value="<?php echo e(old('emergency_phone_no')); ?>">

                                <?php if($errors->has('emergency_phone_no')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('emergency_phone_no')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Emergency Contact Email -->

                        <div class="form-group<?php echo e($errors->has('emergency_email') ? ' has-error' : ''); ?>">
                            <label for="emergency_email" class="col-md-4 control-label">Email Address</label>

                            <div class="col-md-6">
                                <input id="emergency_email" type="email" class="form-control" name="emergency_email" value="<?php echo e(old('emergency_email')); ?>">

                                <?php if($errors->has('emergency_email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('emergency_email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        </p>
                        Your login details. 
                        These will enable you log into the portal and access more features like Bible Study groups and seminar materials.

                        <!-- Password Field -->

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-md-4 control-label">*Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password">

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Confirm Password field -->

                        <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                            <label for="password-confirm" class="col-md-4 control-label">*Confirm Password</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation">

                                <?php if($errors->has('password_confirmation')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-btn fa-user"></i> Register
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>